package com.masterworks.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.masterworks.entity.Student;
import com.masterworks.entity.StudentDto;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer>{
	
	@Query(value="select new com.masterworks.entity.StudentDto (st.id, st.name, st.address, st.enrollmentDate, sb.name) "
			+ "from Subject sb, Student st, StudentSubjectMapping m where st.id=m.sID and sb.id=m.sbID ")
	public List<StudentDto> getAllStudentsAndSubjects();
	
	@Query(value="SELECT st from Student st LEFT JOIN StudentSubjectMapping m on st.id = m.sID where m.sID IS NULL")
	public List<Student> getAllStudentsWithNoSubjects();

}