package com.masterworks.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.masterworks.entity.StudentSubjectMapping;

@Repository
public interface StudentSubjectRepository extends JpaRepository<StudentSubjectMapping, Integer>{

}
