package com.masterworks.entity;

import java.sql.Date;
import java.util.List;

public class StudentDto {
	
	private int id; 
	private String name;
	private String address;
	private Date enrollmentDate;
	private String sbName;
	private List<String> subjects;
	
	public StudentDto() {
		
	}
	public StudentDto(int id, String name, String address, Date enrollmentDate,  String sbName) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.enrollmentDate = enrollmentDate;
		this.sbName = sbName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getEnrollmentDate() {
		return enrollmentDate;
	}
	public void setEnrollmentDate(Date enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}
	public String getSbName() {
		return sbName;
	}
	public void setSbName(String sbName) {
		this.sbName = sbName;
	}
	public List<String> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<String> subjects) {
		this.subjects = subjects;
	}
	
	@Override
	public int hashCode() {
		return this.id;
	}
	
	@Override
	public boolean equals(Object o) {
		if(o==null)
			return false;
		StudentDto dto = (StudentDto) o;
		if(dto.getName().equals(this.name))
			return true;
		return false;
	}
	

}
