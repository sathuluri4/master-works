package com.masterworks.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Student_Subject_mapping")
public class StudentSubjectMapping {
	
	@Id
	@Column(name="s_id")
	private int sID;
	@Id
	@Column(name="sb_id")
	private int sbID;
	
	public int getsID() {
		return sID;
	}
	public void setsID(int sID) {
		this.sID = sID;
	}
	public int getSbID() {
		return sbID;
	}
	public void setSbID(int sbID) {
		this.sbID = sbID;
	}
	
	
	
	
}
