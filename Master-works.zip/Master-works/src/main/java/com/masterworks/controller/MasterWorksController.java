package com.masterworks.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.masterworks.entity.Student;
import com.masterworks.entity.StudentDto;
import com.masterworks.entity.StudentSubjectMapping;
import com.masterworks.services.MasterWorksServices;


@RestController
@RequestMapping("/api")
public class MasterWorksController {
	
	@Autowired
	private MasterWorksServices masterServices;
	
	
	@GetMapping("/getStudents")
	public List<StudentDto> getAllStudentsWithSubjects(){
		return masterServices.getAllStudents();
		
	}
	
	@GetMapping("/getStudentsWithoutSubject")
	public List<Student> getAllStudentsWithNoSubjects(){
		return masterServices.getAllStudentsWithNoSubjects();
	}
	
	@GetMapping("/addSubject")
	public ResponseEntity<StudentSubjectMapping> addSubject(){
		StudentSubjectMapping mapping = masterServices.addSubjectToStudent();
		return new ResponseEntity<StudentSubjectMapping>(mapping, HttpStatus.OK);
	}

}
