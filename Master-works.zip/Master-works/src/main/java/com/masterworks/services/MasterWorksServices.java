package com.masterworks.services;

import java.util.List;

import com.masterworks.entity.Student;
import com.masterworks.entity.StudentDto;
import com.masterworks.entity.StudentSubjectMapping;

public interface MasterWorksServices {
	
	public List<StudentDto> getAllStudents();
	
	public List<Student> getAllStudentsWithNoSubjects();
	
	public StudentSubjectMapping addSubjectToStudent();

}
