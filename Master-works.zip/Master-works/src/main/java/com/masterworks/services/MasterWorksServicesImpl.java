package com.masterworks.services;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.masterworks.dao.StudentRepository;
import com.masterworks.dao.StudentSubjectRepository;
import com.masterworks.entity.Student;
import com.masterworks.entity.StudentDto;
import com.masterworks.entity.StudentSubjectMapping;

@Service
public class MasterWorksServicesImpl implements MasterWorksServices {
	
	
	@Autowired
	StudentRepository repository;
	
	@Autowired
	StudentSubjectRepository mappingRepository;
	
	public List<StudentDto> getAllStudents(){
		
		List<StudentDto> list = repository.getAllStudentsAndSubjects();
		if(list == null  || list.size()==0) {
			return new ArrayList<>();
		}
		Map<Integer, List<String>> map = list.stream().collect(Collectors.groupingBy(StudentDto::getId, Collectors.mapping(StudentDto :: getSbName, Collectors.toList())));
		
		Set<StudentDto> response =  new HashSet<>();
		for(StudentDto dto : list) {
			List<String> subjects = map.get(dto.getId());
			dto.setSubjects(subjects);
			dto.setSbName("");
			response.add(dto);
		}
		
		return new ArrayList<StudentDto>(response);
		
	}
	public List<Student> getAllStudentsWithNoSubjects(){
	
		List<Student> list = repository.getAllStudentsWithNoSubjects() ;
		
		return list==null ? new ArrayList<Student>() : list;  
	}
	
	public StudentSubjectMapping addSubjectToStudent() {
		
		StudentSubjectMapping mapping = new StudentSubjectMapping();
		mapping.setsID(5);
		mapping.setSbID(3);
		mappingRepository.save(mapping);
		return mapping;
	}

}
